dict={}

def func(a):
    for i in a:
        dict[i[0]]=i[1:]
print(dict)




lst=[
[1, 'Jean Castro', 'V'],
[2, 'Lula Powell', 'V'],
[3, 'Brian Howell', 'VI'],
[4, 'Lynne Foster', 'VI'],
[5, 'Zachary Simon', 'VII']
]
func(lst)
print(dict)
